Restore M-VAVE's own firmware on an SMK-37 or FM-1 that runs MD|442 (or is stuck in MD|442's update mode).

Mac: put M-VAVE's firmware file for your keyboard (for example "SMK-37 Elite_016.fwsc") in Downloads,
plug the keyboard straight into the Mac, then double-click "Restore M-VAVE firmware (Mac).command".
The first time, macOS may block it: right-click it, choose Open, then Open again.

Windows or Linux: install Python 3, run  pip install mido python-rtmidi
then in this folder:  python3 tools/fm1_install.py --force "SMK-37 Elite_016.fwsc"
(use M-VAVE's file for your keyboard). Keep the keyboard plugged in until it says done.

fm1_install.py is from X0X (GPL-3.0), with MD|442's changes: https://github.com/mathewdunn89-ggw/MD-442
